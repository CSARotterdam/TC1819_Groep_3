package nl.group3.techlab.helpers;

import android.os.AsyncTask;

public class HttpHelper extends AsyncTask<String, Void, String> {
    @Override
    protected String doInBackground(String... strings) {
        return null;
    }
}
